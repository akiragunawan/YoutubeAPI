package com.example.youtubeapi;

public class config {

    public static final String DEVELOPER_KEY = "AIzaSyCyQ9YjK_i_44cb_J_n_S_DkAOahcxndp0";
    public static final String YOUTUBE_VIDEO_CODE ="vE2ETqUGj6Q";
}
